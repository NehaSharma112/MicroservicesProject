package com.ticket_management_system.database_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatabaseApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
