package com.ticket_management_system.central_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CentralApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CentralApiApplication.class, args);
	}

}
